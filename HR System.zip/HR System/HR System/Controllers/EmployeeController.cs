﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using HR_System.data;
using HR_System.Models;
using HR_System.services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace HR_System.Controllers
{
    public class EmployeeController : Controller
    {

        IEmployeeServices employeeServices;
        IDepartmentServices departmentService;
        IConfiguration configuration;
        public EmployeeController(IEmployeeServices _employeeServices,IDepartmentServices _departmentServices, IConfiguration _configuration )
        {
            employeeServices = _employeeServices;
            departmentService = _departmentServices;
            configuration = _configuration;
        }

        public IActionResult Index()
        {
            List<Department> departments = departmentService.loadall();
            vmEmp vm = new vmEmp();
            vm.lidepartment = departments;
         
            return View("NewEmployee", vm);

        }

        public IActionResult saveEmp(vmEmp vm)
        {
            string name = Guid.NewGuid().ToString() + "." + vm.Employee.image.FileName.Split('.')[1];
            string filePath = Path.Combine(Directory.GetCurrentDirectory(), configuration["FolderName"], name);
            vm.Employee.image.CopyTo(new FileStream(filePath, FileMode.Create));
            vm.Employee.imagepath = name;

            if (ModelState.IsValid == true)
            {
                employeeServices.insert(vm.Employee);
                List<Employee> li = employeeServices.loadall();
                return View("employeelist", li);
            

            }
            else
            {

                List<Employee> li = employeeServices.loadall();
                return View("employeelist", li);
            }



        }

        public IActionResult employeelist()
        {
            //10record
            List<Employee> li = employeeServices.loadall();
            return View("employeelist",li);
        }

        //public IActionResult delet()
        //{
        //    Selecteditemsemployee v = new Selecteditemsemployee();
            

        //    employeeServices.delt(v.TargetSelect);
        //    List<Employee> li = employeeServices.loadall();

        //    return View("employeelist", li);

        //}


    }
}
