﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR_System.Models;
using HR_System.services;
using Microsoft.AspNetCore.Mvc;

namespace HR_System.Controllers
{
    public class AccountController : Controller
    {

        IAcountservices acountservicesInterface;
        public AccountController(IAcountservices _acountservices)
        {
            acountservicesInterface = _acountservices;

        }

        public IActionResult Index()
        {
            return View("creataccount");
        }
        public async Task<IActionResult> createaccount(signupmodl signupmodl)
        {
            var rslt = await acountservicesInterface.creat(signupmodl);

            return View("creataccount");
        }
        public IActionResult Index1()
        {
            return View("loginpage");
        }

        public async Task<IActionResult> userlogin(Login _login)
        {
            var rslt = await acountservicesInterface.login(_login);
            if (rslt.Succeeded)
            {
                return RedirectToAction("Userlist", "Account");

            }

            ViewData["msg"] = "Invaild username or password";
            return View("loginpage");
        }

        public IActionResult Userlist()
        {
            List<ApplicationUser> li = acountservicesInterface.getusers();
            return View("Userlist", li);
        }
        public async Task<IActionResult> logout()
        {
            await acountservicesInterface.logout();

            return View("loginpage");
        }
        public IActionResult NewRole()
        {
            return View("NewRole");
        }
        public async Task<IActionResult> addRole(RoleModle roleModle)
        {
            var rslt = await acountservicesInterface.addrole(roleModle);
            return View("NewRole");
        }



    }
}
