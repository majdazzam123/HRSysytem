﻿namespace HR_System.Controllers
{
    internal interface IAcountservicesInterface
    {
    }
}