﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR_System.data;
using HR_System.services;
using Microsoft.AspNetCore.Mvc;

namespace HR_System.Controllers
{
    public class DepartmentController : Controller
    {
        IDepartmentServices departmentService;


        public DepartmentController(IDepartmentServices _departmentServices)
        { 
      
            departmentService = _departmentServices;

        }
        public IActionResult Index()
        {
            
            return View();
        }
        public IActionResult save(Department dep)
        {

            departmentService.insert(dep);


            return View("Index");
        }
        public IActionResult departmentlist()
        {


          List<Department> li= departmentService.loadall().ToList();

            return View("departmentlist", li);
        }
        public IActionResult Editdep(int id)
        {
            Department dep = departmentService.getUserById(id);
            //Department department = new Department();
            return View("EditInfo", dep);

       }
        public IActionResult updateInfo(Department d)
        {
            departmentService.updatedep(d);
            List<Department> li = new List<Department>();
            return View("departmentlist", li);
        }
        public IActionResult delet(int id)
        {
            departmentService.delt(id);
            List<Department> li = departmentService.loadall();

            return View("departmentlist", li);

        }

    }
}
