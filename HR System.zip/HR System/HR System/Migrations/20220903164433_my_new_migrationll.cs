﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HR_System.Migrations
{
    public partial class my_new_migrationll : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
