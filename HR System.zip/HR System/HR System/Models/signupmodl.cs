﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace HR_System.Models
{
    public class signupmodl
    {
        [Required]
        public string Username { set; get; }
        [Required]
      
        [EmailAddress]
        public string Email { set; get; }
        [Required]
        [Compare("confirmpassword")]
        public string password { set; get; }

        [NotMapped]
        public string confirmpassword { set; get; }
        //[DataType(DataType.PhoneNumber)]
        //[Display(Name = "Phone Number")]
        //[Required(ErrorMessage = "Phone Number Required!")]
        //[RegularExpression(@"^\(?([+9627)])\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$",
        //            ErrorMessage = "Entered phone format is not valid."
            public string PhoneNumber { get; set; }
        public string id { set; get; }

    }
}
