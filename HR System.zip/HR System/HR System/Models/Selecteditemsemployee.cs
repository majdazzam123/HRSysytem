﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HR_System.Models
{
    public class Selecteditemsemployee
    {
        public int[] TargetSelect { set; get; }

    }
}
