﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR_System.data;

namespace HR_System.Models
{
    public class vmEmp
    {
        public Employee Employee { set; get; }
        public List<Department>lidepartment { set; get; }
        public List<Employee> employeesli { set; get; }
    }
}
