﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR_System.data;

namespace HR_System.services
{
    public class EmployeeServices : IEmployeeServices
    {
        context context;

        public EmployeeServices(context _context)
        {

            context = _context;
        }





        public void insert(Employee e)
        {
            DateTime d = DateTime.Now;
            e.CreatedON = d;
            e.Server_Date_Time = d;
            e.Update_DateTime_UTC = d;
            context.employees.Add(e);
            context.SaveChanges();
        }

        public List<Employee> loadall()
        {
            List<Employee> employees = context.employees.ToList();
            return employees;
        }
        public Employee getUserById(int id)
        {
            Employee emp = context.employees.Find(id);
            return emp;
        }
        //public void delt(int[]varr)
        //{

        //    context.employees.RemoveRange(varr);
        //    context.SaveChanges();
        //}


    }
}


