﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR_System.data;

namespace HR_System.services
{
   public interface IDepartmentServices
    {
        void insert(Department dep);
        List<Department> loadall();
        Department getUserById(int id);
        void updatedep(Department department);
        void delt(int id);
    }
}
