﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR_System.Models;
using Microsoft.AspNetCore.Identity;

namespace HR_System.services
{
   public interface IAcountservices
    {
        Task<IdentityResult> creat(signupmodl signupmodl);
        Task<SignInResult> login(Login _login);
        Task logout();
        List<ApplicationUser> getusers();
        Task<IdentityResult> addrole(RoleModle roleModle);
        

  

    }
}
