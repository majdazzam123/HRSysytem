﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR_System.data;
using Microsoft.EntityFrameworkCore;

namespace HR_System.services
{
    public class DepartmentServices:IDepartmentServices
    {
        context context;
        public DepartmentServices(context configuration)
        {
    
            context = configuration;

        }

        public void insert(Department dep)
        {
            DateTime d = DateTime.Now;
            dep.Server_Date_Time = d;
            dep.Update_DateTime_UTC = d;
            dep.DateTime_UTC = d;

            context.departments.Add(dep);
            context.SaveChanges();
        }
        public List<Department> loadall()
        {
           
            List<Department> departments = context.departments.ToList();
            return departments;
        }
        public Department getUserById(int id)
        {
            Department dep = context.departments.Find(id);
            return dep;
        }
        public void  updatedep(Department department)
        {

            context.departments.Attach(department);
            context.Entry(department).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
               
        }

        public void delt(int id)
        {
            Department dep = context.departments.Find(id);
            context.departments.Remove(dep);
            context.SaveChanges();

        }




    }
}
