﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR_System.Models;
using Microsoft.AspNetCore.Identity;

namespace HR_System.services
{
    public class Acountservices:IAcountservices
    {
        UserManager<ApplicationUser> UserManager;
        SignInManager<ApplicationUser> signInManager;
        RoleManager<IdentityRole> roleManager;
        public Acountservices(UserManager<ApplicationUser> _userManager, SignInManager<ApplicationUser> _signInManager,
            RoleManager<IdentityRole> _roleManager)
        {
            UserManager = _userManager;
            signInManager = _signInManager;
            roleManager = _roleManager;
        }

        public async Task<IdentityResult> creat(signupmodl signupmodl)
        {
            
            ApplicationUser user = new ApplicationUser();
            user.UserName = signupmodl.Username;
            user.Email = signupmodl.Email;
            user.PhoneNumber = signupmodl.PhoneNumber;
            


            var result = await UserManager.CreateAsync(user, signupmodl.password);
            return result;

        }
        public async Task<SignInResult> login(Login _login)
        {
            var result = await signInManager.PasswordSignInAsync(_login.Username, _login.password, _login.RememberMe, false);
            return result;
        }
        public async Task logout()
        {
            await signInManager.SignOutAsync();
        }
        public List<ApplicationUser> getusers()
        {
            List<ApplicationUser> liuser = UserManager.Users.ToList();
            return liuser;
        }
      
        public async Task<IdentityResult> addrole(RoleModle roleModle)
        {
            IdentityRole identityRole = new IdentityRole();
            identityRole.Name = roleModle.name;
            var result = await roleManager.CreateAsync(identityRole);
            return result;
        }
      



    }
}
