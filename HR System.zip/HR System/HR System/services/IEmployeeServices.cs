﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR_System.data;

namespace HR_System.services
{
  public interface IEmployeeServices
    {
        void insert(Employee e);
        Employee getUserById(int id);
        
        List<Employee> loadall();
        //void delt(int[] varr);
    }
}
