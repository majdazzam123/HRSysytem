﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HR_System.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace HR_System.data
{
    public class context: IdentityDbContext<ApplicationUser>
    {
        public DbSet<Employee> employees { set; get; }
        public DbSet<Department> departments { set; get; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("data source=localhost; Initial catalog=HRdatabase; Integrated security=true ");
            base.OnConfiguring(optionsBuilder);
        }

    }
}
