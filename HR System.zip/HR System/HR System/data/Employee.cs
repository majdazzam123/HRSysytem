﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace HR_System.data
{
    public class Employee
    {
        public int Id { set; get; }
        [Required]
        public DateTime Server_Date_Time { set; get; }
        public DateTime DateTime_UTC { set; get; }
        public DateTime Update_DateTime_UTC { set; get; }
        [Required]
        public string First_Name { set; get; }
        [Required]
        public string Last_Name { set; get; }
        [Required]
        [EmailAddress]
        public string Email { set; get; }
        [MaxLength(10)]
        public string Mobile_Number { set; get; }
        ////[Required]
        //[DataType(DataType.Password)]
        public string password { set; get; }
        public string Gender { set; get; }
        public string Address { set; get; }
        [NotMapped]
        public IFormFile image { set; get; }
        public string imagepath { set; get; }
        [ForeignKey("Department")]
        public int Department_ID { set; get; }
        public Department department { set; get; }
        public DateTime CreatedON { set; get; }
       
    }
}

