﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace HR_System.data
{
    public class Department
    {
        public int ID { set; get; }
        [Required]
        public string Name { set; get; }
        public DateTime Server_Date_Time { set; get; }
        public DateTime DateTime_UTC { set; get; }
        public DateTime Update_DateTime_UTC { set; get; }
       

        public List<Employee>LiEmployee;
    }
}


