﻿namespace HR_System.data
{
    public interface IFormateFile
    {
    }
}